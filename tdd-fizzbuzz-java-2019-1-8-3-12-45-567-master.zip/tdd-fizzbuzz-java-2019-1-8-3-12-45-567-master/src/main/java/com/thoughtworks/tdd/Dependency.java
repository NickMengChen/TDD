package com.thoughtworks.tdd;

public class Dependency {
    public String say(){
        return "Leave me alone.";
    }
}
